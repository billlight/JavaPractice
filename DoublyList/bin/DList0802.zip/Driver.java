import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

public class Driver { 
	static Stack<Member> myStack = new Stack<>(); 
	static Queue<Member> myQueue = new Queue<>(); 
	static SortedQueue<Member> sQueue = new SortedQueue<>(); 
	static Random r = new Random();
	static Scanner s = new Scanner(System.in);
	static void menu() {
		System.out.println(  "\t+===================================================+\n");
		System.out.println(  "\t|    G: Ask for a N, and generate N members of mixed|\n");
		System.out.println(  "\t|     kinds and put them into three list structures.|\n");
		System.out.println(  "\t|     Make sure you destroy the lists before create |\n");
		System.out.println(  "\t|     new ones if the lists are not empty.          |\n");
		System.out.println(  "\t+---------------------------------------------------+\n");
		System.out.println(  "\t|    S: List members in stack, 1 memebr per line,   |\n");
		System.out.println(  "\t|     20 members per screen with header line, allow |\n");
		System.out.println(  "\t|     Q/q to quit listing after each 20 members.    |\n");
		System.out.println(  "\t|     List last 20 members if quit early.           |\n");
		System.out.println(  "\t+---------------------------------------------------+\n");
		System.out.println(  "\t|    List members in queue (same requirements).     |\n");
		System.out.println(  "\t+---------------------------------------------------+\n");
		System.out.println(  "\t|    O: List members in ordered queue sorted by SSN |\n");
	    System.out.println(  "\t|    (same requirements)                            |\n");
		System.out.println(  "\t+---------------------------------------------------+\n");
		System.out.println(  "\t|    D: Remove first element from queue, pop member |\n");
		System.out.println(  "\t|      from stack, and delete the same member from  |\n");
		System.out.println(  "\t|      sorted queue as the one removed from stack.  |\n");
		System.out.println(  "\t+---------------------------------------------------+\n");
		System.out.println(  "\t|    I: Randomly generate new member, and put       |\n");
		System.out.println(  "\t|      the object into the three structures. Print  |\n");
		System.out.println(  "\t|      out the new member added in.                 |\n");
	    System.out.println(  "\t+---------------------------------------------------+\n");
	    System.out.println(  "\t|    H/?: Display this menu.                        |\n");
	    System.out.println(  "\t|     E  : Exit                                     |\n");
	    System.out.println(  "\t+---------------------------------------------------+\n");
	}
	
	public static Member addItem(int nNums) {
		int k;
		Member mem = new Member();
		for(int i = 0; i < nNums; i++) {
			k = r.nextInt(5);
			switch (k) {
				case 0:
					mem = new Member();
					break;
				case 1:
					mem = new Student();
					break;
				case 2:
					mem = new Employee();
					break;
				case 3:
					mem = new Faculty();
					break;
				case 4:
					mem = new Staff();
					break;
			}
			myStack.push(mem);
			myQueue.enque(mem);
			sQueue.enque(mem);
		}
		return mem;
	}
	public static void show() {
		Iterator<Member> itr = myStack.iterator(true);
		while(itr.hasNext()) {
			System.out.printf("%s\n", itr.next().toString());
		}
		System.out.println();
	}
	
	public static void showStack() {
		Iterator<Member> itr = myStack.iterator(true);
		int count = 0;
		char c = 'c';
		while(itr.hasNext()) {
			count++;
			System.out.printf("%s\n", itr.next().toString());
			if(count % 20 == 0) {
				System.out.printf("Quit?");
				c = s.nextLine().charAt(0);
				if(c == 'q') return;
			}
		}
		System.out.println();
	}

	public static void showQueue() {
		Iterator<Member> itr = myQueue.iterator(true);
		int count = 0;
		char c = 'c';
		while(itr.hasNext()) {
			count++;
			System.out.printf("%s\n", itr.next().toString());
			if(count % 20 == 0) {
				System.out.printf("Quit?");
				c = s.nextLine().charAt(0);
				if(c == 'q') return;
			}
		}
		System.out.println();
	}
	
	public static void showSortQ() {
		Iterator<Member> itr = sQueue.iterator(true);
		int count = 0;
		char c = 'c';
		while(itr.hasNext()) {
			count++;
			System.out.printf("%s\n", itr.next().toString());
			if(count % 20 == 0) {
				System.out.printf("Quit?");
				c = s.nextLine().charAt(0);
				if(c == 'q') return;
			}
		}
		System.out.println();
	}

    public static void main(String[] args) {
    	int N = 0;
	    char c = ' ';	    
	    while ( c != 'e' && c != 'E' ) {
	    	System.out.println("\nEnter H/h/? for help, or command: Q, q to quit or G/S/Q/O/D/I command:\n");
	    	c = s.nextLine().charAt(0);
	    	switch(c) {
	        	case '?': case 'H': case 'h':
	        		menu();
	        		break;
	        	case 'g': case 'G':
	        		System.out.printf("Ask for N\n");
	        		N = s.nextInt(); s.nextLine();
	        		addItem(N);
	        		break;
	        	case 's': case 'S':
	        		showStack();
	        		break;
	        	case 'q': case 'Q':
	        		showQueue();
	        		break;
	        	case 'o': case 'O':
	        		showSortQ();
	        		break;
	        	case 'i': case 'I':
	        		System.out.printf("%s",addItem(1).toString());
	        		break;
	        	case 'd': case 'D':
	    			myStack.pop();
	    			myQueue.deque();
	    			sQueue.deque();
	    			showStack();
	        		break;
	        	case 'e': case 'E':
	        		return;
	    	}
	    }
	}
} 
